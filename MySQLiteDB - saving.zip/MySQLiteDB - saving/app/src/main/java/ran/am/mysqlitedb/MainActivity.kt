package ran.am.mysqlitedb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var edname : EditText
    lateinit var edloc : EditText
    lateinit var btnsave : Button
    var s1 = ""
    var s2 = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        edname=findViewById(R.id.editTextTextPersonName)
        edloc=findViewById(R.id.editTextTextPersonName2)
        btnsave=findViewById(R.id.button)
        btnsave.setOnClickListener {
            s1=edname.text.toString()
            s2=edloc.text.toString()

            var dbhr = DBHlpr(applicationContext)
           var status = dbhr.savedat(s1,s2)
            Toast.makeText(applicationContext, "data saved successfully! "+status, Toast.LENGTH_SHORT).show();
        }
    }
}