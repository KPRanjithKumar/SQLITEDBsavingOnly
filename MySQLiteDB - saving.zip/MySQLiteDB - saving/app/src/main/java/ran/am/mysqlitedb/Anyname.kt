package ran.am.mysqlitedb

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Anyname(context: Context) : SQLiteOpenHelper(context, "details.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null) {
            db.execSQL("create table students (Name text, Location text)")
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {}
}